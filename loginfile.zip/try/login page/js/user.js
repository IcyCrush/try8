document.addEventListener('keydown',function(event){
    if(event.key==='1'){
        window.location.href = "mainuser.html";
    }else if(event.key==='2'){
        window.location.href = "newpolicy.html";
    }else if(event.key==='3'){
        window.location.href = "changepolicy.html";
    }else if(event.key==='4'){
        window.location.href = "renewal.html";
    }else if(event.key==='5'){
        window.location.href = "viewpolicy.html";
    }else if(event.key==='6'){
        window.location.href = "searchpolicy.html";
    }
});
document.getElementById("signout").onclick = function(){
    window.location.href = "index.html";
};



document.getElementById("regi").onclick = function(){
    window.location.href = "newpolicy.html";
};

document.getElementById("viewi").onclick = function(){
    window.location.href = "changepolicy.html";
};

document.getElementById("dismissi").onclick = function(){
    window.location.href = "renewal.html";
};

document.getElementById("uppassi").onclick = function(){
    window.location.href = "viewpolicy.html";
};
