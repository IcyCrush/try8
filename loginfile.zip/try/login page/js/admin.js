document.addEventListener('keydown',function(event){
    if(event.key==='1'){
        window.location.href = "admin.html";
    }else if(event.key==='2'){
        window.location.href = "registration.html";
    }else if(event.key==='3'){
        window.location.href = "view.html";
    }else if(event.key==='4'){
        window.location.href = "dismiss.html";
    }else if(event.key==='5'){
        window.location.href = "update.html";
    }else if(event.key==='6'){
        window.location.href = "search.html";
    }
});
document.getElementById("signout").onclick = function(){
    window.location.href = "index.html";
};


document.getElementById("reg").onclick = function(){
    window.location.href = "registration.html";
};
document.getElementById("regi").onclick = function(){
    window.location.href = "registration.html";
};
document.getElementById("view").onclick = function(){
    window.location.href = "view.html";
};
document.getElementById("viewi").onclick = function(){
    window.location.href = "view.html";
};
document.getElementById("dismiss").onclick = function(){
    window.location.href = "dismiss.html";
};
document.getElementById("dismissi").onclick = function(){
    window.location.href = "dismiss.html";
};
document.getElementById("uppass").onclick = function(){
    window.location.href = "update.html";
};
document.getElementById("uppassi").onclick = function(){
    window.location.href = "update.html";
};
document.getElementById("dash").onclick = function(){
    window.location.href = "admin.html";
};
document.getElementById("searchii").onclick = function(){
    window.location.href = "search.html";
};
document.getElementById("dashi").onclick = function(){
    window.location.href = "admin.html";
};