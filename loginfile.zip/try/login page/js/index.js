function formSubmit() {
    var name = document.getElementById('user').value;
    var pass = document.getElementById('pass').value;
    
    if (name === "admin" && pass === "admin") {
        document.location.href = './admin.html'
    } else if (name === "user" && pass === "user") {
        document.location.href = './mainuser.html'
    } else {
        
        alert("Invalid username or password. Please try again.");
        
        document.getElementById('user').value = "";
        document.getElementById('pass').value = "";
    }
}

function goBackToLogin() {
    document.location.href ='./index.html'
}
